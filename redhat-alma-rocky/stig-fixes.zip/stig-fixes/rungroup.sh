#!/bin/bash

# pass arg "1" 2 etc to run a group of 5; reboot afterward to test

#bkpdest=/mnt/data/notshrcompr # this is where tar backup of root goes if no lvm snapshots
bkpdest=/home/avac_admin  # this is where tar backup of root goes if no lvm snapshots

if [ "$1" = "" ]; then
  argg=1 # default to group 1 if no parm
else
  argg=$1
fi

clear
echo '========================================================='
echo 'DISA STIG fixes for RHEL8'
echo '# 2025.Mar dave.bechtel@linquest.com'
echo ''
echo '! RULE #1 - RUN THESE IN A VM 1ST!!!'
echo '! DO NOT RUN STIG FIXES ON BARE HARDWARE WITHOUT TESTING!'
echo ''
echo "NOTE these fixes are for RHEL8!"
egrep '^NAME|^VERSION' /etc/os-release
echo '========================================================='
echo ''

cd
cd bin/stig-fixes
chmod +x stig*
/bin/rm -fv *~ 
# do not run prev-version files / old code

echo "$(date) - Checking for / making backup of /etc"
mydt=$(date +%Y%m%d_%H%M)

[ -e ~/bkp-etc-$mydt.bkp.tgz ] || time tar czpf ~/bkp-etc-$mydt.bkp.tgz /etc # only overwrite bkpfile if sametime not exist

# lvm snapshot - https://www.golinuxcloud.com/linux-lvm-snapshot-backup-restore-tutorial/#Step_1_Create_LVM_Snapshot_Linux
rootfs=$(df |grep rhel.*root |awk '{print $1}')
#/dev/mapper/rhel_viki-root          xfs        16G   14G  2.0G  88% /

# xxx TODO uncomment
(set -x; lvcreate --size 1G --snapshot --name root_snap_$mydt $rootfs #/dev/mapper/rhel-root
lvs # list snapshot(s)
) 

#echo "$(date) - LVM snapshot unavailable - making tar backup of rootfs on $bkpdest"
echo "$(date) - Making tar backup of rootfs on $bkpdest"
  time tar --use-compress-program pigz \
  --one-file-system \
  --exclude=/boot --exclude=/home --exclude=/mnt --exclude=/proc --exclude=/sys --exclude=/dev --exclude=/run \
  -cpf $bkpdest/bkp-root-$(hostname)-$mydt-b4-stig-group-$argg.tgz /
  date

echo ''
echo "These fixes are designed to be run more than once without issue"
echo "It's not exactly ansible idempotent, but close"
echo ''
echo "Press Enter to run group $argg stig fixes, or ^C"
read

declare -a groupp # bash array
# Yes this is manual, redo with xargs or something if it gets out of hand, this is Q&D
groupp[1]="stig-fix-v-230223 stig-fix-v-230244 stig-fix-v-230252 stig-fix-v-230262 stig-fix-v-230301"
groupp[2]="stig-fix-v-230313 stig-fix-v-230314 stig-fix-v-230329 stig-fix-v-230333 stig-fix-v-230357"
groupp[3]="stig-fix-v-230364 stig-fix-v-230365 stig-fix-v-230373 stig-fix-v-230386 stig-fix-v-230390"
groupp[4]="stig-fix-v-230402 stig-fix-v-230475 stig-fix-v-230482 stig-fix-v-230503 stig-fix-v-230523"
groupp[5]="stig-fix-v-230530 stig-fix-v-230537 stig-fix-v-230550 stig-fix-v-230559 stig-fix-v-237642"
groupp[6]="stig-fix-v-244541 stig-fix-v-257258"


# Teh Main Thing
set -x
#for f in stig*; do
for f in ${groupp[$argg]}; do
#  echo ./$f # test before run
  ./$f
  date
done
set +x

echo "NOTE - /root/fstab.edit MUST be manually vetted and tested before replacing /etc/fstab!"
echo "If you 	/bin/cp -vf ~/fstab.edit ~/etc/fstab 	and   ' mount -a '  works OK, then should be fine"
echo "Otherwise ls -al /etc/fstab* 	and restore a backup!"
echo ''
echo "$(date) - A reboot is REQUIRED now - then rerun the stig scan"

exit;


# group1 = OK
stig-fix-v-230223
stig-fix-v-230244
stig-fix-v-230252
stig-fix-v-230262
stig-fix-v-230301

#2 = OK
stig-fix-v-230313
stig-fix-v-230314
stig-fix-v-230329
stig-fix-v-230333
stig-fix-v-230357

#3 = OK
stig-fix-v-230364
stig-fix-v-230365
stig-fix-v-230373
stig-fix-v-230386
stig-fix-v-230390

#4 - OK
stig-fix-v-230402
stig-fix-v-230475
stig-fix-v-230482
stig-fix-v-230503
stig-fix-v-230523

#5 - OK
stig-fix-v-230530
stig-fix-v-230537
stig-fix-v-230550
stig-fix-v-230559
stig-fix-v-237642

#6 - 
stig-fix-v-244541
stig-fix-v-257258


PROTIPs:

If you wish to keep the software update changes, then you can choose to remove the LVM snapshot. To execute LVM remove snapshot

# To delete snapshot:
# lvremove /dev/rhel/data_snap
Do you really want to remove active logical volume rhel/data_snap? [y/n]: y
  Logical volume "data_snap" successfully removed
  
=====

o To Perform LVM restore snapshot for root file system:

Since we cannot unmount root file system runtime, we will initiate the LVM
restore snapshot command.  The actual restore will happen at the reboot
stage when root is in unmounted state.

# lvconvert --merge /dev/rhel/root_snap
  Delaying merge since origin is open.
  Merging of snapshot rhel/root_snap will occur on next activation of rhel/root.

As you see we get a warning "Delaying merge since origin is open", so now the lvm restore snapshot will happen after next reboot.

=====

To perform a LVM restore snapshot you must unmount the respective logical
volume.  Now you can easily unmount data partition but you cannot unmount
parimary partition such as root partition runtime in our case.

To restore snapshot:
# lvconvert --merge /dev/rhel/data_snap
  Merging of volume rhel/data_snap started.
  rhel/data: Merged: 31.04%
  rhel/data: Merged: 100.00%  

=====

With RHEL 7.7 and higher releases you can use BOOM utility to boot your
RHEL/CentOS node using the LVM snapshot.  So instead of mounting the LVM
snapshot and then working on these logical volumes, you can boot using the
LVM snapshot using BOOM and then perform an read/write operation.

https://www.golinuxcloud.com/boom-boot-linux-lvm-snapshot-rhel-8-linux/

=====

If things go drastically wrong and the system will not boot:

boot grub to rd.break
#mount /sysroot rw
#chroot /sysroot
#rm -rf etc
#tar xzpf /root/bkp-etc*.tgz # use date on backup to restore /etc as it was before STIG changes  without extra files
#touch .autorelabel
#reboot

Also turn off FIPS mode: 
# fips-mode-setup --disable && reboot
