#!/bin/bash

echo "o $0 - Quick check for v-230537, all results should be 0"
for d in /run/sysctl.d/*.conf /usr/local/lib/sysctl.d/*.conf /usr/lib/sysctl.d/*.conf /lib/sysctl.d/*.conf /etc/sysctl.conf /etc/sysctl.d/*.conf; do
#  grep -R -ic icmp_echo_ignore_broadcasts $d
  grep -H -R -ic kernel.yama.ptrace_scope $d
done
