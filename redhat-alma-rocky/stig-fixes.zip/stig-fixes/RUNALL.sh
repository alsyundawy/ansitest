#!/bin/bash

# 2025.Mar dave.bechtel@linquest.com

echo '! RULE #1 - RUN THIS IN A VM 1ST!!!'
echo '! DO NOT RUN THIS ON BARE HARDWARE WITHOUT TESTING!'
echo ''
echo "NOTE these fixes are for RHEL8!"
egrep '^NAME|^VERSION' /etc/os-release

cd
cd bin/stig-fixes
chmod +x stig*
/bin/rm -fv *~ 
# do not run prev-version files / old code

echo "$(date) - Checking for / making backup of /etc"
mydt=$(date +%Y%m%d@%H%M)

[ -e ~/bkp-etc-$mydt.bkp.tgz ] || time tar czpf ~/bkp-etc-$mydt.bkp.tgz /etc # only overwrite bkpfile if sametime not exist

# lvm snapshot - https://www.golinuxcloud.com/linux-lvm-snapshot-backup-restore-tutorial/#Step_1_Create_LVM_Snapshot_Linux
rootfs=$(df |grep rhel.*root |awk '{print $1}')
#/dev/mapper/rhel_viki-root          xfs        16G   14G  2.0G  88% /

(set -x; lvcreate --size 1G --snapshot --name root_snap-$mydt $rootfs #/dev/mapper/rhel-root
)
lvs # list snapshot(s)

echo "These fixes are designed to be run more than once without issue"
echo "It's not exactly ansible idempotent, but close"
echo ''
echo "Press Enter to run stig fixes, or ^C"
read


# Teh Main Thing
set -x
for f in stig*; do
  ./$f
  date
done
set -x

echo "NOTE - /root/fstab.edit MUST be manually vetted and tested before replacing /etc/fstab!"
echo "If you 	/bin/cp -vf ~/fstab.edit ~/etc/fstab 	and   ' mount -a '  works OK, then should be fine"
echo "Otherwise ls -al /etc/fstab* 	and restore a backup!"
echo ''
echo "($date) - A reboot is REQUIRED now - then rerun the stig scan"

exit;


PROTIPs:

If you wish to keep the software update changes, then you can choose to remove the LVM snapshot. To execute LVM remove snapshot

# To delete snapshot:
# lvremove /dev/rhel/data_snap
Do you really want to remove active logical volume rhel/data_snap? [y/n]: y
  Logical volume "data_snap" successfully removed
  
=====

o To Perform LVM restore snapshot for root file system:

Since we cannot unmount root file system runtime, we will initiate the LVM
restore snapshot command.  The actual restore will happen at the reboot
stage when root is in unmounted state.

# lvconvert --merge /dev/rhel/root_snap
  Delaying merge since origin is open.
  Merging of snapshot rhel/root_snap will occur on next activation of rhel/root.

As you see we get a warning "Delaying merge since origin is open", so now the lvm restore snapshot will happen after next reboot.

=====

To perform a LVM restore snapshot you must unmount the respective logical
volume.  Now you can easily unmount data partition but you cannot unmount
parimary partition such as root partition runtime in our case.

To restore snapshot:
# lvconvert --merge /dev/rhel/data_snap
  Merging of volume rhel/data_snap started.
  rhel/data: Merged: 31.04%
  rhel/data: Merged: 100.00%  

=====

With RHEL 7.7 and higher releases you can use BOOM utility to boot your
RHEL/CentOS node using the LVM snapshot.  So instead of mounting the LVM
snapshot and then working on these logical volumes, you can boot using the
LVM snapshot using BOOM and then perform an read/write operation.

https://www.golinuxcloud.com/boom-boot-linux-lvm-snapshot-rhel-8-linux/

=====

If things go drastically wrong and the system will not boot:

boot grub to rd.break
#mount /sysroot rw
#chroot /sysroot
#rm -rf etc
#tar xzpf /root/bkp-etc*.tgz # use date on backup to restore /etc as it was before STIG changes  without extra files
#touch .autorelabel
#reboot

Also turn off FIPS mode: 
# fips-mode-setup --disable && reboot
